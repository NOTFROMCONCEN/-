package com.demo.floatwindowdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MyReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction().toString();
		if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
			System.out.println("手机开机了....");
			// startUploadService(context);
		}
		if (Intent.ACTION_USER_PRESENT.equals(intent.getAction())) {
			// startUploadService(context);
		}
	}
}
