package com.demo.floatwindowdemo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class DrawCView extends View {

	public DrawCView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
		int HEIGHT = 0;
		int WIDHT = 0;
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		WIDHT = canvas.getWidth();
		HEIGHT = canvas.getHeight();
		paint.setColor(Color.DKGRAY);
		System.out.println(String.valueOf(WIDHT) + HEIGHT);
		canvas.drawCircle(getWidth() / 2, getHeight() / 2, getWidth() / 2,
				paint);
		paint.setColor(Color.BLACK);
		canvas.drawCircle(getWidth() / 2, getHeight() / 2, getWidth() / 4,
				paint);
	}
}
