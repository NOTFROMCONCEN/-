package com.demo.floatwindowdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Toast;

public class MainActivity extends Activity {
	private CountDownTimer timer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		ScreenUtils.initScreen(this);
		Intent intent = new Intent(MainActivity.this, FloatWindowService.class);
		startService(intent);
		timer = new CountDownTimer(1000, 2000) {

			@Override
			public void onTick(long millisUntilFinished) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onFinish() {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "服务已启动",
						Toast.LENGTH_SHORT).show();
				finish();
			}
		}.start();
	}
}
