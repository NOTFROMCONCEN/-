package com.example.dklauncherdemo.activitys;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;

import com.example.dklauncherdemo.R;

public class MockHome extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mock_home);
	}
}
